@echo off
start "" "%LOCALAPPDATA%\Programs\Android Studio\bin\studio64.exe" "%cd%"
if errorlevel 1 start "" "C:\Program Files\Android\Android Studio\bin\studio64.exe" "%cd%"
