# Ferramentas de Combate — APK WebView

Projeto Android nativo em WebView para transformar as Ferramentas de Combate em APK.

## Novidades desta versão

- Importa backups da própria ferramenta.
- Importa fichas JSON compatíveis, como as fichas exportadas do projeto RPG.
- Detecta fichas com `transformado` e permite importar a versão transformada.
- Detecta `Jogando sem Sanidade` quando a ficha possui `_modoSemSanidade`, `pdA` ou `pdM`.
- Adiciona aba **Regras Opcionais**.
- Adiciona modo **Jogando sem Sanidade**:
  - PE/SAN viram PD.
  - Custos de PE usam PD.
  - Perda de SAN e dano mental podem ser aplicados em PD.
  - Conversor de dano mental de criaturas.
  - Marca automaticamente Perturbado/Enlouquecendo conforme a regra, quando o dano mental afeta PD.
- Adiciona modo **Combate Narrativo**:
  - Troca as ações tradicionais por ação simples, complexa e extrema.
  - Mostra distância narrativa: toque, curta, média e longa.
  - Usa valor de Iniciativa fixa.
  - Mostra dano médio, crítico médio e coreografia x2/x3.
  - Adiciona botões Narrativo x2 e Narrativo x3 nos ataques.

## Gerar APK pelo GitHub Actions

1. Crie um repositório no GitHub.
2. Envie este ZIP para a raiz do repositório.
3. Crie o arquivo `.github/workflows/build-apk.yml`, ou use o workflow que já está dentro do projeto.
4. Rode em `Actions > Gerar APK WebView > Run workflow`.
5. Baixe o artifact gerado.

## Gerar APK pelo Android Studio

1. Extraia o ZIP.
2. Abra a pasta do projeto no Android Studio.
3. Aguarde o Gradle sincronizar.
4. Use `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

O APK debug normalmente aparece em:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Observação

A ferramenta continua sendo um HTML offline dentro do app. Todo o salvamento é local, no próprio aparelho.


## Versão interface corrigida

Esta versão inclui ajustes para uso em celular/APK:

- abas em barra horizontal fixa e rolável;
- botões maiores para toque;
- cartões com bordas arredondadas;
- layout mais compacto em telas pequenas;
- inicialização protegida com tela de erro se algum save antigo travar o carregamento;
- limpeza automática de save corrompido ao carregar.

Se o app abrir em branco, toque em **Resetar** ou use o botão **Limpar save e reabrir** que aparece na tela de erro.
